---
inclusion: always
---

# Development Workflow

## Starting the server
```powershell
Set-Location "c:\Users\plaks\OneDrive\Desktop\smart 1\kiro0\smart-campus-lost-and-found"
python app.py
```
Server restarts automatically on file save (debug=True).  
Open: **http://127.0.0.1:5000**

## First-time admin setup
Register a normal account at `/auth`, then promote it once:
```powershell
Set-Location "c:\Users\plaks\OneDrive\Desktop\smart 1\kiro0\smart-campus-lost-and-found"
python -c "
import sqlite3
c = sqlite3.connect('campus.db')
c.execute(\"UPDATE users SET role='admin' WHERE username='YOUR_USERNAME'\")
c.commit()
print('Done')
"
```
After that, any admin can promote other users via Admin → Users tab.

## Testing approach
Run the integration test script (if present) before committing:
```powershell
python run_tests.py
```
All 55 checks must pass. Tests use unique timestamped usernames so they are safe to re-run on the live DB.

## Database inspection
```powershell
Set-Location "c:\Users\plaks\OneDrive\Desktop\smart 1\kiro0\smart-campus-lost-and-found"
python -c "
import sqlite3
conn = sqlite3.connect('campus.db')
conn.row_factory = sqlite3.Row
tables = conn.execute(\"SELECT name FROM sqlite_master WHERE type='table'\").fetchall()
for t in tables:
    cols = conn.execute(f'PRAGMA table_info({t[0]})').fetchall()
    print(t[0], ':', [c[1] for c in cols])
conn.close()
"
```

## Adding a new feature checklist
- [ ] Read current `app.py` and relevant template before writing anything
- [ ] Add DB tables/columns with `_add_col()` migration — never recreate tables
- [ ] Strip sensitive fields (`owner_token`, `proof_answer_hash`) from all public responses
- [ ] Add `@login_required` or `@admin_required` decorator to protected routes
- [ ] Update relevant template (add link/section) if UI is needed
- [ ] Run syntax check: `python -m py_compile app.py`
- [ ] Run integration tests

## Common pitfalls
- **CSS not loading** → always access via `http://127.0.0.1:5000`, not Live Server
- **DB locked** → only one Flask process at a time; WAL mode handles concurrent reads
- **Session lost on restart** → `app.secret_key` regenerates each restart in dev; use a fixed key for production
- **Jinja not rendering** → HTML is only rendered when served by Flask, not opened as a file
