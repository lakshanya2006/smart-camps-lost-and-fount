---
inclusion: fileMatch
fileMatchPattern: "*.css,*.html,*.js"
---

# UI & Style Guide

## Design system
All styles live in `static/style.css`. The design uses CSS custom properties (variables) — always use them, never hardcode colours.

### Colour tokens
```css
--primary:       #6847ed   /* purple — primary actions, links, active states */
--primary-dark:  #5031d4   /* hover state for primary */
--primary-light: #ede9ff   /* tinted backgrounds, hover fills */
--ink:           #20213a   /* body text */
--muted:         #73758d   /* secondary text, labels */
--surface:       #ffffff   /* card backgrounds */
--page:          #f6f5fc   /* page background */
--border:        #e9e7f3   /* card borders, dividers */
--success:       #16865c   /* green — recovered, approved */
--success-bg:    #e7f8ef
--danger:        #dc4560   /* red — lost, errors, rejected */
--danger-bg:     #fff0f2
--warn:          #b45309   /* amber — pending, warnings */
--warn-bg:       #fffbeb
--radius:        20px       /* default card radius */
--shadow-sm:     0 4px 14px rgba(43,34,92,.05)
--shadow-md:     0 8px 28px rgba(43,34,92,.09)
--shadow-lg:     0 18px 48px rgba(43,34,92,.14)
```

### Typography
- Font: `Inter` (Google Fonts) with `Arial` fallback
- Body: 13–14px / line-height 1.6
- Headings: tight letter-spacing (`-0.5px` to `-2px`)
- Labels/badges: 10–11px, `font-weight: 800`, `text-transform: uppercase`

### Gradients
- Hero: `linear-gradient(120deg, #4a25d4 0%, #7958f2 55%, #a17cf9 100%)`
- User sidebar: `linear-gradient(160deg, #4a25d4, #7958f2)`
- Admin sidebar: `linear-gradient(160deg, #1e1060, #4a25d4)` (darker)

## Component patterns

### Status badges
```html
<span class="badge lost">lost</span>
<span class="badge found">found</span>
<span class="badge open">open</span>
<span class="badge recovered">recovered</span>
<span class="badge pending">pending</span>
<span class="badge approved">approved</span>
<span class="badge rejected">rejected</span>
```

### Primary button
```html
<button class="primary-btn">Action →</button>
<a class="primary-btn" href="/path">Link button</a>
```

### Cards
```html
<div class="stat-card">
  <span>Label</span>
  <strong>Value</strong>
</div>

<article class="item-card">
  <!-- item content -->
</article>
```

### Modals
Always include a `.modal-backdrop` wrapper with `hidden` class toggled by JS. Use `role="dialog"` and `aria-modal="true"`.

## JavaScript conventions
- No framework — vanilla ES2020+
- `esc(value)` for all user-generated HTML interpolation — never use `innerHTML = userValue` directly
- `fmtDate(value)` for all timestamp formatting
- `fetch()` with `Content-Type: application/json` for all API calls
- Check `r.ok` before reading JSON body
- All form submit handlers call `event.preventDefault()`

## Responsiveness
- Mobile breakpoints: `700px` (single column) and `420px` (minimal)
- Sidebars hide at `700px` via `display:none`
- Stat grids collapse from 4→2→1 columns
- Always test that forms are usable on a 375px viewport

## Accessibility
- All modal dialogs: `role="dialog"`, `aria-modal="true"`, `aria-labelledby`
- Live regions for form feedback: `role="status"`, `aria-live="polite"`
- Buttons with icon-only content need `title` or `aria-label`
- Colour is never the only indicator of state — always pair with text or icon
