---
inclusion: always
---

# CampusFind – Project Steering Guide

## Project overview
CampusFind is a **Privacy-First Smart Campus Lost & Found** system built with:
- **Backend:** Python 3, Flask 3.0, SQLite (WAL mode, foreign keys on)
- **Frontend:** Vanilla HTML/CSS/JS — no frontend framework, no bundler
- **Auth:** Werkzeug `generate_password_hash` / `check_password_hash`, Flask signed sessions
- **No external services** — everything runs locally; zero paid APIs

## Project root
```
smart-campus-lost-and-found/
├── app.py                  # Single Flask application — all routes here
├── campus.db               # SQLite database — never delete
├── requirements.txt        # flask==3.0.3  werkzeug==3.0.3
├── static/
│   ├── style.css           # All styles — one file
│   └── script.js           # All public-page JS — one file
└── templates/
    ├── index.html          # Public feed (Jinja2)
    ├── auth.html           # Login + register page
    ├── dashboard.html      # User dashboard
    └── admin.html          # Admin dashboard
```

## How to run
```powershell
Set-Location "c:\Users\plaks\OneDrive\Desktop\smart 1\kiro0\smart-campus-lost-and-found"
python app.py
# → http://127.0.0.1:5000
```
**Always access via `http://127.0.0.1:5000` — never via Live Server or file://.**

## Database schema (current)
| Table | Key columns |
|---|---|
| `items` | id, item_type, title, category, location, description, contact, status, user_id, hidden, proof_hint, proof_answer_hash, owner_token |
| `users` | id, username, email, password_hash, role (user/admin) |
| `messages` | id, item_id, thread_id, sender_role, sender_id, body |
| `claims` | id, item_id, claimer_token, claimer_user_id, proof_correct, status, admin_note |
| `notifications` | id, item_id, match_id, score, reason, seen |
| `user_notifications` | id, user_id, kind, title, body, link_item_id, seen |
| `audit_log` | id, admin_id, action, target_type, target_id, note |

All DB changes must use **additive migrations** via `_add_col()` — never drop or recreate tables.

## API surface
### Public
- `GET /api/items` — all visible items + smart matches
- `POST /api/items` — submit report (works logged-in or anonymous)
- `GET /api/stats` — total/lost/found/matched counts
- `POST /api/message/start` — start anonymous thread
- `POST /api/message/reply` — reply to thread
- `GET /api/message/thread/<id>` — read thread (token required)
- `POST /api/claim` — submit ownership claim
- `POST /api/claim/owner` — owner approve/reject claim

### Auth-required (`/api/my/…`)
- `GET /api/my/items` — my reports
- `PUT /api/items/<id>` — edit own report
- `DELETE /api/items/<id>` — hide own report
- `GET /api/my/notifications` — user notifications
- `GET /api/my/notifications/unread` — unread count
- `POST /api/my/notifications/mark-read` — mark read
- `GET /api/my/messages` — message thread list

### Admin-only (`/api/admin/…`)
- `GET /api/admin/users` — list users
- `PUT /api/admin/users/<id>` — change role
- `PUT /api/admin/items/<id>` — edit any item
- `PUT /api/admin/claims/<id>` — approve/reject/note claim
- `GET /api/admin/stats` — extended stats

## Coding rules for this project
1. **Never use `git add .` or `git add -A`** — stage specific files only.
2. **One `app.py`** — do not split into blueprints unless explicitly requested.
3. **No new dependencies** — Flask + Werkzeug + stdlib only. If a new package is genuinely needed, ask first.
4. **Parameterized SQL always** — no string-formatted queries.
5. **Strip `owner_token` and `proof_answer_hash`** from every public API response.
6. **Admin checks are server-side** — never rely on UI hiding alone.
7. **`hidden=1` is soft-delete** — never hard-delete items.
8. Static files are served by Flask at `/static/`. CSS link: `{{ url_for('static', filename='style.css') }}`.
