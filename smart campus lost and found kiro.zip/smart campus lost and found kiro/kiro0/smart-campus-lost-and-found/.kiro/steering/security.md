---
inclusion: always
---

# Security Rules

These rules apply to every code change in this project. Never bypass them.

## Authentication & sessions
- Passwords are hashed with `werkzeug.security.generate_password_hash` (pbkdf2:sha256 by default).
- Plain-text passwords must never be stored, logged, or returned in any response.
- Sessions are Flask signed cookies (`app.secret_key`). In production, use a fixed secret stored outside the repo (environment variable).
- After logout, call `session.clear()`.

## Authorization
- **Every route** that touches user-specific data must be decorated with `@login_required`.
- **Every admin route** must be decorated with `@admin_required` or call `_check_admin()`.
- Client-side UI hiding (disabling buttons, hiding menus) is **not** authorization — always enforce on the server.
- A user must never be able to edit, delete, or read another user's private data. Check `item["user_id"] == session["user_id"]` before every write.

## Input validation
- Use `_clean()` / `_validate_fields()` for all user input.
- Apply length limits on every field (see `app.py` `limits` dict).
- `item_type` must be validated against `("lost", "found")` exactly.
- Escape all user-supplied values in HTML using `esc()` in JavaScript and Jinja2 auto-escaping in templates.

## SQL
- Every SQL query must use `?` placeholders — never f-strings or `%` formatting.
- Example of what is **never** allowed: `f"SELECT * FROM items WHERE title='{title}'"`.

## Sensitive fields
These fields must **never** appear in public API responses:
- `owner_token` — always `item.pop("owner_token", None)` before returning
- `proof_answer_hash` — always `item.pop("proof_answer_hash", None)` before returning
- `password_hash` — never selected in user-facing queries

## Proof-of-ownership
- Proof answers are hashed with SHA-256 via `_hash()` before storage.
- The raw answer is never stored or returned.
- Comparison: `_hash(submitted_answer) == stored_hash` — constant-time comparison is not required here because timing differences don't reveal the hash.

## Rate limiting
- Max 3 pending claims per item enforced in `submit_claim()`.
- No global rate limiting in dev; add Flask-Limiter before production deployment.

## Production hardening checklist (before going live)
- [ ] Set `app.secret_key` from environment variable, not generated at startup
- [ ] Set `debug=False`
- [ ] Add HTTPS (use a reverse proxy like nginx + certbot)
- [ ] Set `SESSION_COOKIE_SECURE = True`, `SESSION_COOKIE_HTTPONLY = True`, `SESSION_COOKIE_SAMESITE = "Lax"`
- [ ] Add Flask-Limiter for rate limiting
- [ ] Consider CSRF tokens for state-changing form submissions
