# CampusFind – Feature Specification

## Project summary
CampusFind is a privacy-first smart campus lost-and-found system. Students report lost or found items, the system matches them automatically, and parties communicate anonymously. Ownership is verified privately via a secret question/answer challenge.

---

## Completed features

### Core (Phase 1)
- [x] Public report feed with search and filter (all / lost / found / open / recovered)
- [x] Submit report form (lost or found, with category, location, description)
- [x] Smart match engine — scores two items of opposite types on category, location, title words, description words
- [x] Match notifications stored per item — displayed in item cards with reasons

### Privacy Shield (Phase 2)
- [x] Anonymous messaging via thread tokens — neither party's identity is revealed
- [x] Proof-of-ownership challenge — secret question/answer, answer hashed (SHA-256), never stored plain
- [x] Owner can approve/reject claims using owner token
- [x] Rate limit: max 3 pending claims per item

### Auth + Dashboards (Phase 3)
- [x] User registration and login (Werkzeug bcrypt, Flask sessions)
- [x] User dashboard — my reports (edit/delete), smart matches, claims, messages, notification bell
- [x] Admin dashboard — stats overview, all reports, claims review, user management, audit log
- [x] Role-based access control — server-side `@login_required` and `@admin_required`
- [x] Soft-delete (hidden=1) — items removed from feed without DB deletion
- [x] User-level notifications — match alerts, claim decisions, message alerts; unread count; mark-as-read
- [x] Audit log — records every admin action with target and note

---

## Pending / future features

### Phase 4 — Polish & production
- [ ] Fix `app.secret_key` to load from environment variable (not regenerated at restart)
- [ ] Add `SESSION_COOKIE_SECURE`, `SESSION_COOKIE_HTTPONLY`, `SESSION_COOKIE_SAMESITE`
- [ ] Add Flask-Limiter for rate limiting on login, register, claim endpoints
- [ ] CSRF token on all state-changing form submissions
- [ ] Email confirmation on registration (requires SMTP config)
- [ ] Password reset via email token
- [ ] Pagination on public feed and admin tables (currently loads all items)

### Phase 5 — Enhanced matching
- [ ] Image upload for item photos (proof of description)
- [ ] Campus map integration — click location on map instead of text field
- [ ] Category-specific matching rules (e.g. ID card serial number field)
- [ ] Duplicate detection — warn before submitting if very similar item exists

### Phase 6 — Analytics
- [ ] Recovery rate chart (items recovered / total reported, over time)
- [ ] Heatmap of item loss locations by campus building
- [ ] Category breakdown pie chart in admin dashboard
- [ ] Export reports to CSV from admin dashboard

---

## Non-functional requirements
- Zero external runtime dependencies beyond Flask + Werkzeug
- All DB changes must be backward-compatible (additive only)
- Page must load and be usable without JavaScript for the public feed (progressive enhancement)
- Must work on Chrome, Firefox, Edge (latest 2 versions)
- Mobile-responsive at 375px minimum viewport width
