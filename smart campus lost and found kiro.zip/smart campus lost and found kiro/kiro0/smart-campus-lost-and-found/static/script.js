/* ═══════════════════════════════════════════════
   CampusFind – Privacy-First Smart Recovery
   ═══════════════════════════════════════════════ */

/* ── State ──────────────────────────────────────── */
let allItems      = [];
let activeFilter  = "all";
let activeMsgItemId   = null;
let activeClaimItemId = null;
let lastOwnerToken    = null;   // stored in memory only

/* ── DOM refs ───────────────────────────────────── */
const form        = document.getElementById("itemForm");
const formMessage = document.getElementById("formMessage");
const itemsList   = document.getElementById("itemsList");
const searchInput = document.getElementById("searchInput");
const filters     = document.querySelectorAll(".filter");

/* ── Utilities ──────────────────────────────────── */
function esc(v) {
  return String(v ?? "").replace(/[&<>"']/g, c =>
    ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" })[c]
  );
}

function fmtDate(v) {
  if (!v) return "";
  const d = new Date(v.replace(" ", "T") + "Z");
  return isNaN(d) ? v : d.toLocaleString([], { dateStyle:"medium", timeStyle:"short" });
}

function setMsg(el, text, type) {
  el.textContent = text;
  el.className   = type || "";
}

function copyText(text, btn) {
  navigator.clipboard.writeText(text).then(() => {
    const orig = btn.textContent;
    btn.textContent = "Copied!";
    setTimeout(() => btn.textContent = orig, 1800);
  });
}

/* ── Stats ──────────────────────────────────────── */
async function loadStats() {
  try {
    const r = await fetch("/api/stats");
    if (!r.ok) return;
    const s = await r.json();
    document.getElementById("totalCount").textContent   = s.total;
    document.getElementById("lostCount").textContent    = s.lost;
    document.getElementById("foundCount").textContent   = s.found;
    document.getElementById("matchedCount").textContent = s.matched ?? 0;
  } catch { /* silent */ }
}

/* ── Items ──────────────────────────────────────── */
async function loadItems() {
  itemsList.innerHTML = '<p class="empty-state">Loading reports…</p>';
  try {
    const r = await fetch("/api/items");
    if (!r.ok) throw new Error();
    allItems = await r.json();
    renderItems();
  } catch {
    itemsList.innerHTML = '<p class="empty-state">Unable to load reports. Refresh to try again.</p>';
  }
}

function renderItems() {
  const q = searchInput.value.trim().toLowerCase();

  const visible = allItems.filter(item => {
    const filterMatch =
      activeFilter === "all"       ? true :
      activeFilter === "lost"      ? item.item_type === "lost" :
      activeFilter === "found"     ? item.item_type === "found" :
      activeFilter === "open"      ? (item.status || "open") === "open" :
      activeFilter === "recovered" ? item.status === "recovered" : true;

    if (!filterMatch) return false;
    if (!q) return true;
    return [item.title, item.category, item.location, item.description]
      .join(" ").toLowerCase().includes(q);
  });

  if (!visible.length) {
    itemsList.innerHTML = `
      <div class="empty-state">
        <h3>No reports found</h3>
        <p>Try a different search or submit a new report.</p>
      </div>`;
    return;
  }

  itemsList.innerHTML = visible.map(item => cardHTML(item)).join("");
}

function cardHTML(item) {
  const statusLabel = item.status === "recovered" ? "recovered" : item.item_type;
  const recovered   = item.status === "recovered";

  /* matches */
  const matches = Array.isArray(item.matches) ? item.matches : [];
  const matchHTML = matches.length ? `
    <div class="match-box">
      <strong>⚡ Smart Match – possible links</strong>
      ${matches.map(m => `
        <div class="match-entry">
          <span class="match-score">${esc(m.score)}%</span>
          <strong>${esc(m.title)}</strong> · ${esc(m.item_type)} · ${esc(m.location)}
          ${m.reasons?.length ? `<div class="match-reasons">${m.reasons.map(esc).join(" · ")}</div>` : ""}
        </div>`).join("")}
    </div>` : "";

  /* proof badge */
  const proofBadge = item.proof_hint
    ? `<span class="proof-badge">🔐 Ownership challenge set</span>` : "";

  /* action buttons */
  let actions = "";
  if (!recovered) {
    if (item.item_type === "lost" && item.proof_hint) {
      actions += `<button class="action-btn" onclick="openClaimModal(${item.id}, '${esc(item.title)}', '${esc(item.proof_hint)}')">🔐 Prove Ownership</button>`;
    }
    actions += `<button class="action-btn" onclick="openMsgModal(${item.id}, '${esc(item.title)}')">💬 Contact Anonymously</button>`;
  }

  return `
    <article class="item-card${recovered ? " recovered-card" : ""}">
      <div class="item-card-top">
        <span class="status ${statusLabel}">${esc(statusLabel)}</span>
        <span class="item-category">${esc(item.category)}</span>
      </div>
      <h3>${esc(item.title)}</h3>
      <p class="item-description">${esc(item.description)}</p>
      ${proofBadge}
      <div class="item-meta">
        <span>📍 ${esc(item.location)}</span>
        <span>🕒 ${esc(fmtDate(item.created_at))}</span>
      </div>
      ${matchHTML}
      ${actions ? `<div class="card-actions">${actions}</div>` : ""}
    </article>`;
}

/* ── Filters & search ───────────────────────────── */
filters.forEach(btn => {
  btn.addEventListener("click", () => {
    activeFilter = btn.dataset.filter;
    filters.forEach(b => b.classList.toggle("active", b === btn));
    renderItems();
  });
});
searchInput.addEventListener("input", renderItems);

/* ── Submit report form ─────────────────────────── */
form.addEventListener("submit", async e => {
  e.preventDefault();
  const btn = form.querySelector('button[type="submit"]');
  btn.disabled = true;
  btn.textContent = "Submitting…";
  setMsg(formMessage, "", "");
  document.getElementById("ownerTokenBox").classList.add("hidden");

  const fd   = new FormData(form);
  const data = Object.fromEntries(fd.entries());

  try {
    const r   = await fetch("/api/items", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const res = await r.json();
    if (!r.ok) throw new Error(res.error || "Submit failed.");

    setMsg(formMessage, res.message || "Report submitted!", "success");
    form.reset();
    document.getElementById("proofFields").classList.add("hidden");
    document.getElementById("proofToggle").textContent = "Show ▸";

    /* show owner token once */
    if (res.owner_token) {
      lastOwnerToken = res.owner_token;
      document.getElementById("ownerTokenDisplay").textContent = res.owner_token;
      document.getElementById("ownerTokenBox").classList.remove("hidden");
    }

    activeFilter = "all";
    filters.forEach(b => b.classList.toggle("active", b.dataset.filter === "all"));
    await Promise.all([loadItems(), loadStats()]);

    document.getElementById("feed").scrollIntoView({ behavior:"smooth", block:"start" });
  } catch (err) {
    setMsg(formMessage, err.message, "error");
  } finally {
    btn.disabled = false;
    btn.textContent = "Submit report →";
  }
});

/* ── Proof toggle ───────────────────────────────── */
function toggleProof() {
  const fields = document.getElementById("proofFields");
  const btn    = document.getElementById("proofToggle");
  const hidden = fields.classList.toggle("hidden");
  btn.textContent = hidden ? "Show ▸" : "Hide ▴";
}

/* ── Copy helpers ───────────────────────────────── */
function copyOwnerToken() {
  const tok = document.getElementById("ownerTokenDisplay").textContent;
  copyText(tok, document.querySelector(".token-box .copy-btn"));
}
function copyThreadToken() {
  const tok = document.getElementById("threadTokenDisplay").textContent;
  copyText(tok, document.querySelector("#msgResult .copy-btn"));
}

/* ── Modal helpers ──────────────────────────────── */
function closeModal(id) {
  document.getElementById(id).classList.add("hidden");
}

document.addEventListener("keydown", e => {
  if (e.key === "Escape") {
    ["msgModal","claimModal","ownerModal","threadModal"].forEach(closeModal);
  }
});

/* ═══════════════════════════════════════════════
   FEATURE 1 – Privacy Shield (anonymous messages)
   ═══════════════════════════════════════════════ */

function openMsgModal(itemId, title) {
  activeMsgItemId = itemId;
  document.getElementById("msgModalSub").textContent =
    `Item #${itemId}: "${title}"`;
  document.getElementById("msgBody").value = "";
  document.getElementById("msgResult").classList.add("hidden");
  document.getElementById("msgThreadView").classList.add("hidden");
  document.getElementById("msgThreadView").innerHTML = "";
  document.getElementById("msgModal").classList.remove("hidden");
  document.getElementById("msgBody").focus();
}

async function sendMessage() {
  const body = document.getElementById("msgBody").value.trim();
  if (!body) return;

  try {
    const r = await fetch("/api/message/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ item_id: activeMsgItemId, body }),
    });
    const res = await r.json();
    if (!r.ok) throw new Error(res.error || "Send failed.");

    document.getElementById("threadTokenDisplay").textContent =
      res.thread_id + "::" + (res.claimer_token || "");
    document.getElementById("msgResult").classList.remove("hidden");
    document.getElementById("msgBody").value = "";
  } catch (err) {
    alert("Error: " + err.message);
  }
}

/* ── Read thread (claimer side) ─────────────────── */
async function readThread() {
  const raw   = document.getElementById("readThreadId").value.trim();
  const token = document.getElementById("readThreadToken").value.trim();
  const msg   = document.getElementById("threadModalMsg");

  // accept "threadId::claimerToken" pasted from token box
  let threadId = raw;
  let useToken = token;
  if (raw.includes("::") && !token) {
    [threadId, useToken] = raw.split("::");
    document.getElementById("readThreadId").value    = threadId;
    document.getElementById("readThreadToken").value = useToken;
  }

  if (!threadId || !useToken) {
    setMsg(msg, "Provide thread ID and token.", "error"); return;
  }

  try {
    const r = await fetch(
      `/api/message/thread/${encodeURIComponent(threadId)}?token=${encodeURIComponent(useToken)}`
    );
    const res = await r.json();
    if (!r.ok) throw new Error(res.error || "Not found.");

    const view = document.getElementById("readThreadView");
    renderThread(view, res.messages, res.role);
    setMsg(msg, "", "");
  } catch (err) {
    setMsg(msg, err.message, "error");
  }
}

function renderThread(container, messages, myRole) {
  if (!messages.length) {
    container.innerHTML = "<p style='color:var(--muted);font-size:13px'>No messages yet.</p>";
    return;
  }
  container.innerHTML = messages.map(m => `
    <div class="msg-bubble ${m.sender_role}">
      ${esc(m.body)}
      <div class="msg-meta">${m.sender_role === "reporter" ? "Owner" : "Contact"} · ${esc(fmtDate(m.created_at))}</div>
    </div>`).join("");
  container.scrollTop = container.scrollHeight;
}

async function sendThreadReply() {
  const threadId = document.getElementById("readThreadId").value.trim();
  const token    = document.getElementById("readThreadToken").value.trim();
  const body     = document.getElementById("readReplyBody").value.trim();
  const msg      = document.getElementById("threadModalMsg");

  if (!threadId || !token || !body) {
    setMsg(msg, "Thread ID, token, and message are required.", "error"); return;
  }

  try {
    const r = await fetch("/api/message/reply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ thread_id: threadId, token, body }),
    });
    const res = await r.json();
    if (!r.ok) throw new Error(res.error || "Reply failed.");
    document.getElementById("readReplyBody").value = "";
    setMsg(msg, "Reply sent!", "success");
    readThread();   // refresh
  } catch (err) {
    setMsg(msg, err.message, "error");
  }
}

function openThreadModal() {
  document.getElementById("readThreadId").value    = "";
  document.getElementById("readThreadToken").value = "";
  document.getElementById("readReplyBody").value   = "";
  document.getElementById("readThreadView").innerHTML = "";
  setMsg(document.getElementById("threadModalMsg"), "", "");
  document.getElementById("threadModal").classList.remove("hidden");
}

/* ═══════════════════════════════════════════════
   FEATURE 2 – Smart Match (notifications)
   – handled server-side; displayed in item cards
   and in owner panel (see below)
   ═══════════════════════════════════════════════ */

/* ═══════════════════════════════════════════════
   FEATURE 3 – Proof-of-Ownership Claim
   ═══════════════════════════════════════════════ */

function openClaimModal(itemId, title, hint) {
  activeClaimItemId = itemId;
  document.getElementById("claimModalTitle").textContent = "🔐 Prove Ownership";
  document.getElementById("claimModalSub").textContent   = `Item #${itemId}: "${title}"`;
  document.getElementById("claimHintBox").textContent    = "🔑 Hint: " + hint;
  document.getElementById("claimAnswer").value           = "";
  setMsg(document.getElementById("claimResult"), "", "");
  document.getElementById("claimModal").classList.remove("hidden");
  document.getElementById("claimAnswer").focus();
}

async function submitClaim() {
  const answer = document.getElementById("claimAnswer").value.trim();
  const result = document.getElementById("claimResult");
  if (!answer) { setMsg(result, "Enter your answer.", "error"); return; }

  try {
    const r = await fetch("/api/claim", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ item_id: activeClaimItemId, proof_answer: answer }),
    });
    const res = await r.json();
    if (!r.ok) throw new Error(res.error || "Claim failed.");

    if (res.result === "approved") {
      setMsg(result, res.message, "success");
      document.getElementById("claimAnswer").value = "";
      await Promise.all([loadItems(), loadStats()]);
    } else {
      setMsg(result, res.message, "error");
    }
  } catch (err) {
    setMsg(result, err.message, "error");
  }
}

/* ═══════════════════════════════════════════════
   FEATURE 4 – Owner Panel (messages + claims + notifications)
   ═══════════════════════════════════════════════ */

function openOwnerPanel() {
  const itemId = lastOwnerToken
    ? ""
    : document.getElementById("ownerItemId")?.value || "";
  document.getElementById("ownerItemId").value    = itemId;
  document.getElementById("ownerTokenInput").value = lastOwnerToken || "";
  document.getElementById("ownerPanelContent").classList.add("hidden");
  setMsg(document.getElementById("ownerPanelMsg"), "", "");
  document.getElementById("ownerModal").classList.remove("hidden");
}

function switchOwnerTab(tab) {
  ["messages","claims","notifications"].forEach(t => {
    document.getElementById(`ownerTab${t.charAt(0).toUpperCase()+t.slice(1)}`).classList.toggle("hidden", t !== tab);
    document.querySelector(`.owner-tab[data-tab="${t}"]`).classList.toggle("active", t === tab);
  });
}

async function loadOwnerPanel() {
  const itemId = parseInt(document.getElementById("ownerItemId").value);
  const token  = document.getElementById("ownerTokenInput").value.trim();
  const msg    = document.getElementById("ownerPanelMsg");

  if (!itemId || !token) {
    setMsg(msg, "Provide item ID and owner token.", "error"); return;
  }
  setMsg(msg, "Loading…", "");

  try {
    const [claimsR, notifsR] = await Promise.all([
      fetch(`/api/claims/${itemId}?owner_token=${encodeURIComponent(token)}`),
      fetch(`/api/notifications/${itemId}?owner_token=${encodeURIComponent(token)}`),
    ]);

    if (!claimsR.ok || !notifsR.ok) {
      const e = await (claimsR.ok ? notifsR : claimsR).json();
      throw new Error(e.error || "Forbidden — check item ID and token.");
    }

    const claims  = await claimsR.json();
    const notifs  = await notifsR.json();

    renderOwnerClaims(claims, itemId, token);
    renderOwnerNotifications(notifs);
    document.getElementById("ownerMessages").innerHTML =
      `<p class="help-text">To read a specific thread, use the <button class="link-btn" onclick="openThreadModal()">Read Thread</button> feature.</p>`;

    document.getElementById("ownerPanelContent").classList.remove("hidden");
    setMsg(msg, "", "");
  } catch (err) {
    setMsg(msg, err.message, "error");
  }
}

function renderOwnerClaims(claims, itemId, token) {
  const el = document.getElementById("ownerClaims");
  if (!claims.length) {
    el.innerHTML = '<p class="help-text">No claims yet.</p>'; return;
  }
  el.innerHTML = claims.map(c => `
    <div class="claim-row">
      <div>Claim #${c.id} — <span class="claim-status ${c.status}">${c.status}</span>
        · Correct: ${c.proof_correct ? "✅ Yes" : "❌ No"}
        · ${fmtDate(c.created_at)}</div>
      ${c.status === "pending" ? `
        <div class="claim-actions">
          <button class="action-btn" onclick="ownerActClaim(${c.id},'approve',${itemId},'${esc(token)}')">✅ Approve</button>
          <button class="action-btn danger" onclick="ownerActClaim(${c.id},'reject',${itemId},'${esc(token)}')">❌ Reject</button>
        </div>` : ""}
    </div>`).join("");
}

async function ownerActClaim(claimId, action, itemId, token) {
  try {
    const r = await fetch("/api/claim/owner", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ owner_token: token, claim_id: claimId, action }),
    });
    const res = await r.json();
    if (!r.ok) throw new Error(res.error);
    setMsg(document.getElementById("ownerPanelMsg"), res.message, "success");
    loadOwnerPanel();
    loadItems();
    loadStats();
  } catch (err) {
    setMsg(document.getElementById("ownerPanelMsg"), err.message, "error");
  }
}

function renderOwnerNotifications(notifs) {
  const el = document.getElementById("ownerNotifications");
  if (!notifs.length) {
    el.innerHTML = '<p class="help-text">No smart-match notifications yet.</p>'; return;
  }
  el.innerHTML = notifs.map(n => `
    <div class="notif-row">
      <span class="notif-score">${n.score}%</span>
      <strong>${esc(n.match_title)}</strong> (${esc(n.match_type)})
      · ${esc(n.match_location)}
      <div class="match-reasons">${esc(n.reason)}</div>
      <div style="font-size:11px;color:var(--muted);margin-top:4px">${fmtDate(n.created_at)}</div>
    </div>`).join("");
}

async function ownerReply() {
  const itemId   = parseInt(document.getElementById("ownerItemId").value);
  const token    = document.getElementById("ownerTokenInput").value.trim();
  const threadId = document.getElementById("ownerReplyThread").value.trim();
  const body     = document.getElementById("ownerReplyBody").value.trim();
  const msg      = document.getElementById("ownerPanelMsg");

  if (!threadId || !body) {
    setMsg(msg, "Thread ID and message required.", "error"); return;
  }

  try {
    const r = await fetch("/api/message/reply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ thread_id: threadId, token, body }),
    });
    const res = await r.json();
    if (!r.ok) throw new Error(res.error || "Reply failed.");
    document.getElementById("ownerReplyBody").value = "";
    setMsg(msg, "Reply sent!", "success");
  } catch (err) {
    setMsg(msg, err.message, "error");
  }
}

/* ── Bootstrap ──────────────────────────────────── */
loadItems();
loadStats();
