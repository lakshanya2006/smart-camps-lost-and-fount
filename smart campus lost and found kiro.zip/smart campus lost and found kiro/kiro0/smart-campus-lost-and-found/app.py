﻿# app.py – CampusFind  (full auth + admin + notifications upgrade)
from flask import (
    Flask, render_template, request, jsonify,
    session, redirect, url_for, abort, g,
)
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3, re, hashlib, secrets, functools
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
app = Flask(
    __name__,
    template_folder=str(BASE_DIR / "templates"),
    static_folder=str(BASE_DIR / "static"),
    static_url_path="/static",
)
app.secret_key = secrets.token_hex(32)   # regenerated each restart – fine for dev

DB_PATH = BASE_DIR / "campus.db"

# ── DB connection ────────────────────────────────────────────
def connect_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

# ── Schema + safe migrations ─────────────────────────────────
def init_db():
    with connect_db() as conn:
        # ── users ────────────────────────────────────────────
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                username     TEXT NOT NULL UNIQUE COLLATE NOCASE,
                email        TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                role         TEXT NOT NULL DEFAULT 'user'
                             CHECK(role IN ('user','admin')),
                created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )""")

        # ── items (original + migrations) ───────────────────
        conn.execute("""
            CREATE TABLE IF NOT EXISTS items (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                item_type     TEXT NOT NULL,
                title         TEXT NOT NULL,
                category      TEXT NOT NULL,
                location      TEXT NOT NULL,
                description   TEXT NOT NULL,
                contact       TEXT NOT NULL,
                created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )""")
        _add_col(conn, "items", "owner_token",       "TEXT DEFAULT NULL")
        _add_col(conn, "items", "proof_hint",         "TEXT DEFAULT NULL")
        _add_col(conn, "items", "proof_answer_hash",  "TEXT DEFAULT NULL")
        _add_col(conn, "items", "status",             "TEXT DEFAULT 'open'")
        _add_col(conn, "items", "user_id",            "INTEGER DEFAULT NULL")
        _add_col(conn, "items", "hidden",             "INTEGER DEFAULT 0")

        # ── messages ────────────────────────────────────────
        conn.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                item_id     INTEGER NOT NULL REFERENCES items(id),
                thread_id   TEXT NOT NULL,
                sender_role TEXT NOT NULL CHECK(sender_role IN ('reporter','claimer','user')),
                sender_id   INTEGER DEFAULT NULL,
                body        TEXT NOT NULL,
                created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_msg_thread ON messages(thread_id)")
        _add_col(conn, "messages", "sender_id", "INTEGER DEFAULT NULL")

        # ── claims ──────────────────────────────────────────
        conn.execute("""
            CREATE TABLE IF NOT EXISTS claims (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                item_id         INTEGER NOT NULL REFERENCES items(id),
                claimer_token   TEXT NOT NULL UNIQUE,
                claimer_user_id INTEGER DEFAULT NULL,
                proof_answer    TEXT NOT NULL,
                proof_correct   INTEGER DEFAULT 0,
                status          TEXT DEFAULT 'pending'
                                CHECK(status IN ('pending','approved','rejected')),
                admin_note      TEXT DEFAULT NULL,
                created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_claims_item ON claims(item_id)")
        _add_col(conn, "claims", "claimer_user_id", "INTEGER DEFAULT NULL")
        _add_col(conn, "claims", "admin_note",       "TEXT DEFAULT NULL")

        # ── smart-match notifications (item-level, legacy) ──
        conn.execute("""
            CREATE TABLE IF NOT EXISTS notifications (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                item_id     INTEGER NOT NULL REFERENCES items(id),
                match_id    INTEGER NOT NULL REFERENCES items(id),
                score       INTEGER NOT NULL,
                reason      TEXT NOT NULL,
                seen        INTEGER DEFAULT 0,
                created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_notif_item ON notifications(item_id)")

        # ── user notifications (account-level) ──────────────
        conn.execute("""
            CREATE TABLE IF NOT EXISTS user_notifications (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER NOT NULL REFERENCES users(id),
                kind        TEXT NOT NULL,
                title       TEXT NOT NULL,
                body        TEXT NOT NULL,
                link_item_id INTEGER DEFAULT NULL,
                seen        INTEGER DEFAULT 0,
                created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_un_user ON user_notifications(user_id)")

        # ── audit log ───────────────────────────────────────
        conn.execute("""
            CREATE TABLE IF NOT EXISTS audit_log (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_id    INTEGER NOT NULL REFERENCES users(id),
                action      TEXT NOT NULL,
                target_type TEXT,
                target_id   INTEGER,
                note        TEXT,
                created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )""")

def _add_col(conn, table, col, definition):
    existing = {r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    if col not in existing:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {definition}")

init_db()

# ── Decorators ───────────────────────────────────────────────
def login_required(f):
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            # API routes (prefixed /api/) always return JSON 401
            if request.path.startswith("/api/") or request.is_json:
                return jsonify({"error": "Login required."}), 401
            return redirect(url_for("auth_page") + "?next=" + request.path)
        return f(*args, **kwargs)
    return wrapper

def admin_required(f):
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("auth_page"))
        if session.get("role") != "admin":
            abort(403)
        return f(*args, **kwargs)
    return wrapper

# ── Matching helpers (unchanged) ────────────────────────────
def _words(v):
    return set(re.findall(r"[a-z0-9]+", str(v).lower()))

def _match_score(a, b):
    if a["item_type"] == b["item_type"]:
        return 0, []
    score, reasons = 0, []
    if a["category"].lower() == b["category"].lower():
        score += 40; reasons.append(f"Same category ({a['category']})")
    if a["location"].lower() == b["location"].lower():
        score += 20; reasons.append(f"Same location ({a['location']})")
    tw_a, tw_b = _words(a["title"]), _words(b["title"])
    if tw_a or tw_b:
        r = int(30 * len(tw_a & tw_b) / max(len(tw_a | tw_b), 1))
        if r: score += r; reasons.append(f"Similar title ({r}% word overlap)")
    dw_a, dw_b = _words(a["description"]), _words(b["description"])
    r = int(10 * len(dw_a & dw_b) / max(len(dw_a | dw_b), 1))
    if r: score += r
    return min(score, 100), reasons

def find_matches(item, all_items):
    out = []
    for o in all_items:
        if o["id"] == item["id"]: continue
        sc, rs = _match_score(item, o)
        if sc >= 30:
            out.append({"id": o["id"], "title": o["title"],
                        "item_type": o["item_type"], "category": o["category"],
                        "location": o["location"], "score": sc, "reasons": rs})
    return sorted(out, key=lambda x: x["score"], reverse=True)[:5]

def _store_match_notifications(new_item, all_items, conn):
    for o in all_items:
        if o["id"] == new_item["id"]: continue
        sc, rs = _match_score(new_item, o)
        if sc >= 40:
            rstr = "; ".join(rs)
            conn.execute(
                "INSERT INTO notifications(item_id,match_id,score,reason) VALUES(?,?,?,?)",
                (new_item["id"], o["id"], sc, rstr))
            conn.execute(
                "INSERT INTO notifications(item_id,match_id,score,reason) VALUES(?,?,?,?)",
                (o["id"], new_item["id"], sc, rstr))
            # user-level notification for the matched item's owner
            owner_uid = o.get("user_id")
            if owner_uid:
                _push_user_notif(conn, owner_uid, "match",
                    f"Smart match: {new_item['title']}",
                    f"{sc}% match with your report #{o['id']} — {rstr}",
                    o["id"])
            # user-level notification for the new item's owner
            new_uid = new_item.get("user_id")
            if new_uid:
                _push_user_notif(conn, new_uid, "match",
                    f"Smart match found for your report",
                    f"{sc}% match with '{o['title']}' — {rstr}",
                    new_item["id"])

def _push_user_notif(conn, user_id, kind, title, body, item_id=None):
    conn.execute(
        """INSERT INTO user_notifications(user_id,kind,title,body,link_item_id)
           VALUES(?,?,?,?,?)""",
        (user_id, kind, title, body, item_id))

# ── Validation ───────────────────────────────────────────────
def _hash(t):
    return hashlib.sha256(t.strip().lower().encode()).hexdigest()

def _token():
    return secrets.token_urlsafe(24)

def _clean(data, required, limits):
    out = {}
    for f in required:
        v = str(data.get(f, "")).strip()
        if not v: raise ValueError(f"{f.replace('_',' ').title()} is required.")
        if f in limits and len(v) > limits[f]:
            raise ValueError(f"{f.replace('_',' ').title()} max {limits[f]} chars.")
        out[f] = v
    return out

def _audit(conn, action, target_type=None, target_id=None, note=None):
    conn.execute(
        "INSERT INTO audit_log(admin_id,action,target_type,target_id,note) VALUES(?,?,?,?,?)",
        (session["user_id"], action, target_type, target_id, note))

# ════════════════════════════════════════════════════════════
# PAGE ROUTES
# ════════════════════════════════════════════════════════════

@app.route("/")
def home():
    user = None
    if session.get("user_id"):
        with connect_db() as conn:
            user = conn.execute(
                "SELECT id,username,role FROM users WHERE id=?",
                (session["user_id"],)).fetchone()
            if user: user = dict(user)
    return render_template("index.html", user=user)

@app.route("/auth")
def auth_page():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    return render_template("auth.html")

@app.route("/dashboard")
@login_required
def dashboard():
    with connect_db() as conn:
        user = dict(conn.execute(
            "SELECT id,username,email,role,created_at FROM users WHERE id=?",
            (session["user_id"],)).fetchone())
        items = [dict(r) for r in conn.execute(
            "SELECT * FROM items WHERE user_id=? ORDER BY id DESC",
            (session["user_id"],)).fetchall()]
        unread = conn.execute(
            "SELECT COUNT(*) FROM user_notifications WHERE user_id=? AND seen=0",
            (session["user_id"],)).fetchone()[0]
    return render_template("dashboard.html", user=user, items=items, unread=unread)

@app.route("/admin")
@admin_required
def admin_page():
    with connect_db() as conn:
        users  = [dict(r) for r in conn.execute(
            "SELECT id,username,email,role,created_at FROM users ORDER BY id DESC").fetchall()]
        items  = [dict(r) for r in conn.execute(
            "SELECT i.*,u.username FROM items i LEFT JOIN users u ON i.user_id=u.id ORDER BY i.id DESC"
        ).fetchall()]
        claims = [dict(r) for r in conn.execute(
            """SELECT c.*,i.title as item_title,u.username as claimer_name
               FROM claims c
               JOIN items i ON c.item_id=i.id
               LEFT JOIN users u ON c.claimer_user_id=u.id
               ORDER BY c.id DESC"""
        ).fetchall()]
        stats  = dict(conn.execute("""
            SELECT
              (SELECT COUNT(*) FROM items)          AS total_items,
              (SELECT COUNT(*) FROM items WHERE item_type='lost')  AS lost,
              (SELECT COUNT(*) FROM items WHERE item_type='found') AS found,
              (SELECT COUNT(*) FROM items WHERE status='recovered') AS recovered,
              (SELECT COUNT(*) FROM users)          AS total_users,
              (SELECT COUNT(*) FROM claims)         AS total_claims,
              (SELECT COUNT(*) FROM claims WHERE status='pending') AS pending_claims
        """).fetchone())
        logs = [dict(r) for r in conn.execute(
            """SELECT a.*,u.username as admin_name FROM audit_log a
               JOIN users u ON a.admin_id=u.id ORDER BY a.id DESC LIMIT 100"""
        ).fetchall()]
    return render_template("admin.html",
        users=users, items=items, claims=claims, stats=stats, logs=logs,
        admin_user={"username": session.get("username"), "id": session.get("user_id")})

# ════════════════════════════════════════════════════════════
# AUTH API
# ════════════════════════════════════════════════════════════

@app.route("/api/auth/register", methods=["POST"])
def register():
    d = request.get_json(silent=True) or {}
    username = str(d.get("username","")).strip()
    email    = str(d.get("email","")).strip().lower()
    password = str(d.get("password","")).strip()
    if not username or not email or not password:
        return jsonify({"error": "All fields required."}), 400
    if len(username) < 3 or len(username) > 40:
        return jsonify({"error": "Username must be 3–40 characters."}), 400
    if not re.match(r"^[^@]+@[^@]+\.[^@]+$", email):
        return jsonify({"error": "Invalid email address."}), 400
    if len(password) < 6:
        return jsonify({"error": "Password must be at least 6 characters."}), 400
    pw_hash = generate_password_hash(password)
    try:
        with connect_db() as conn:
            cur = conn.execute(
                "INSERT INTO users(username,email,password_hash) VALUES(?,?,?)",
                (username, email, pw_hash))
            uid = cur.lastrowid
            session.clear()
            session["user_id"] = uid
            session["username"] = username
            session["role"] = "user"
    except sqlite3.IntegrityError:
        return jsonify({"error": "Username or email already taken."}), 409
    return jsonify({"message": f"Welcome, {username}!", "redirect": "/dashboard"}), 201

@app.route("/api/auth/login", methods=["POST"])
def login():
    d = request.get_json(silent=True) or {}
    identifier = str(d.get("identifier","")).strip()
    password   = str(d.get("password","")).strip()
    if not identifier or not password:
        return jsonify({"error": "Username/email and password required."}), 400
    with connect_db() as conn:
        user = conn.execute(
            "SELECT * FROM users WHERE username=? OR email=?",
            (identifier, identifier.lower())).fetchone()
    if not user or not check_password_hash(user["password_hash"], password):
        return jsonify({"error": "Invalid credentials."}), 401
    session.clear()
    session["user_id"]  = user["id"]
    session["username"] = user["username"]
    session["role"]     = user["role"]
    dest = "/admin" if user["role"] == "admin" else "/dashboard"
    return jsonify({"message": f"Welcome back, {user['username']}!", "redirect": dest})

@app.route("/api/auth/logout", methods=["POST"])
def logout():
    session.clear()
    return jsonify({"redirect": "/"})

@app.route("/api/auth/me", methods=["GET"])
def me():
    if not session.get("user_id"):
        return jsonify({"logged_in": False})
    return jsonify({
        "logged_in": True,
        "user_id":  session["user_id"],
        "username": session["username"],
        "role":     session["role"],
    })

# ════════════════════════════════════════════════════════════
# ITEMS API (existing + user ownership)
# ════════════════════════════════════════════════════════════

@app.route("/api/items", methods=["GET"])
def get_items():
    with connect_db() as conn:
        rows = conn.execute(
            "SELECT * FROM items WHERE hidden=0 ORDER BY id DESC").fetchall()
    items = [dict(r) for r in rows]
    for item in items:
        item.pop("owner_token", None); item.pop("proof_answer_hash", None)
        item["matches"] = find_matches(item, items)
    return jsonify(items)

@app.route("/api/items", methods=["POST"])
def add_item():
    d = request.get_json(silent=True) or {}
    try:
        c = _clean(d, ["item_type","title","category","location","description","contact"],
                   {"title":100,"category":100,"location":100,"description":500,"contact":150})
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    c["item_type"] = c["item_type"].lower()
    if c["item_type"] not in ("lost","found"):
        return jsonify({"error": "Choose Lost or Found."}), 400
    proof_hint      = str(d.get("proof_hint","")).strip()[:200]
    proof_ans_hash  = _hash(str(d.get("proof_answer","")).strip()) if d.get("proof_answer") else None
    owner_token     = _token()
    user_id         = session.get("user_id")
    with connect_db() as conn:
        cur = conn.execute(
            """INSERT INTO items(item_type,title,category,location,description,
               contact,proof_hint,proof_answer_hash,owner_token,user_id)
               VALUES(?,?,?,?,?,?,?,?,?,?)""",
            (c["item_type"],c["title"],c["category"],c["location"],
             c["description"],c["contact"],proof_hint or None,
             proof_ans_hash,owner_token,user_id))
        iid  = cur.lastrowid
        row  = dict(conn.execute("SELECT * FROM items WHERE id=?", (iid,)).fetchone())
        all_items = [dict(r) for r in conn.execute("SELECT * FROM items").fetchall()]
        _store_match_notifications(row, all_items, conn)
    row.pop("owner_token",None); row.pop("proof_answer_hash",None)
    row["matches"] = find_matches(row, all_items)
    return jsonify({"message": "Report submitted!", "item": row,
                    "owner_token": owner_token}), 201

@app.route("/api/items/<int:item_id>", methods=["PUT"])
@login_required
def edit_item(item_id):
    with connect_db() as conn:
        item = conn.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
        if not item:
            return jsonify({"error": "Not found."}), 404
        if item["user_id"] != session["user_id"] and session.get("role") != "admin":
            return jsonify({"error": "Forbidden."}), 403
        d = request.get_json(silent=True) or {}
        fields, vals = [], []
        for col in ("title","category","location","description","contact","proof_hint"):
            if col in d:
                fields.append(f"{col}=?"); vals.append(str(d[col]).strip()[:500])
        if "status" in d and session.get("role") == "admin":
            fields.append("status=?"); vals.append(d["status"])
        if not fields:
            return jsonify({"error": "Nothing to update."}), 400
        vals.append(item_id)
        conn.execute(f"UPDATE items SET {','.join(fields)} WHERE id=?", vals)
    return jsonify({"message": "Updated."})

@app.route("/api/items/<int:item_id>", methods=["DELETE"])
@login_required
def delete_item(item_id):
    with connect_db() as conn:
        item = conn.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
        if not item:
            return jsonify({"error": "Not found."}), 404
        if item["user_id"] != session["user_id"] and session.get("role") != "admin":
            return jsonify({"error": "Forbidden."}), 403
        conn.execute("UPDATE items SET hidden=1 WHERE id=?", (item_id,))
        if session.get("role") == "admin":
            _audit(conn, "hide_item", "item", item_id, f"Hidden: {item['title']}")
    return jsonify({"message": "Report removed."})

@app.route("/api/my/items", methods=["GET"])
@login_required
def my_items():
    with connect_db() as conn:
        rows = conn.execute(
            "SELECT * FROM items WHERE user_id=? ORDER BY id DESC",
            (session["user_id"],)).fetchall()
    items = [dict(r) for r in rows]
    for it in items:
        it.pop("owner_token",None); it.pop("proof_answer_hash",None)
    return jsonify(items)

# ════════════════════════════════════════════════════════════
# STATS
# ════════════════════════════════════════════════════════════

@app.route("/api/stats")
def stats():
    with connect_db() as conn:
        total   = conn.execute("SELECT COUNT(*) FROM items WHERE hidden=0").fetchone()[0]
        lost    = conn.execute("SELECT COUNT(*) FROM items WHERE item_type='lost' AND hidden=0").fetchone()[0]
        found   = conn.execute("SELECT COUNT(*) FROM items WHERE item_type='found' AND hidden=0").fetchone()[0]
        matched = conn.execute("SELECT COUNT(*) FROM items WHERE status='recovered' AND hidden=0").fetchone()[0]
    return jsonify({"total":total,"lost":lost,"found":found,"matched":matched})

# ════════════════════════════════════════════════════════════
# PRIVACY SHIELD (messages) – unchanged API surface
# ════════════════════════════════════════════════════════════

@app.route("/api/message/start", methods=["POST"])
def message_start():
    d = request.get_json(silent=True) or {}
    item_id = int(d.get("item_id", 0))
    body    = str(d.get("body","")).strip()[:1000]
    if not item_id or not body:
        return jsonify({"error": "item_id and body required."}), 400
    with connect_db() as conn:
        item = conn.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
        if not item: return jsonify({"error": "Item not found."}), 404
        thread_id     = _token()
        claimer_token = _token()
        uid           = session.get("user_id")
        conn.execute(
            "INSERT INTO messages(item_id,thread_id,sender_role,sender_id,body) VALUES(?,?,?,?,?)",
            (item_id, thread_id, "claimer", uid, body))
        # notify item owner if they have an account
        if item["user_id"]:
            _push_user_notif(conn, item["user_id"], "message",
                f"New anonymous message on report #{item_id}",
                body[:120], item_id)
    return jsonify({"thread_id": thread_id, "claimer_token": claimer_token,
                    "message": "Message sent. Save thread token to reply."}), 201

@app.route("/api/message/reply", methods=["POST"])
def message_reply():
    d = request.get_json(silent=True) or {}
    thread_id = str(d.get("thread_id","")).strip()
    body      = str(d.get("body","")).strip()[:1000]
    token     = str(d.get("token","")).strip()
    if not thread_id or not body or not token:
        return jsonify({"error": "thread_id, body, token required."}), 400
    with connect_db() as conn:
        first = conn.execute(
            "SELECT item_id FROM messages WHERE thread_id=? LIMIT 1", (thread_id,)).fetchone()
        if not first: return jsonify({"error": "Thread not found."}), 404
        item = conn.execute(
            "SELECT * FROM items WHERE id=?", (first["item_id"],)).fetchone()
        if not item: return jsonify({"error": "Item not found."}), 404
        role = "reporter" if token == item["owner_token"] else "claimer"
        uid  = session.get("user_id")
        conn.execute(
            "INSERT INTO messages(item_id,thread_id,sender_role,sender_id,body) VALUES(?,?,?,?,?)",
            (item["id"], thread_id, role, uid, body))
    return jsonify({"message": "Reply sent."})

@app.route("/api/message/thread/<thread_id>")
def get_thread(thread_id):
    token = request.args.get("token","").strip()
    if not token: return jsonify({"error": "Token required."}), 403
    with connect_db() as conn:
        first = conn.execute(
            "SELECT item_id FROM messages WHERE thread_id=? LIMIT 1", (thread_id,)).fetchone()
        if not first: return jsonify({"error": "Thread not found."}), 404
        item = conn.execute(
            "SELECT owner_token FROM items WHERE id=?", (first["item_id"],)).fetchone()
        rows = conn.execute(
            "SELECT sender_role,body,created_at FROM messages WHERE thread_id=? ORDER BY id",
            (thread_id,)).fetchall()
    return jsonify({
        "item_id":  first["item_id"],
        "role":     "reporter" if (item and token == item["owner_token"]) else "claimer",
        "messages": [dict(r) for r in rows],
    })

# ════════════════════════════════════════════════════════════
# USER MESSAGES (dashboard inbox)
# ════════════════════════════════════════════════════════════

@app.route("/api/my/messages")
@login_required
def my_messages():
    uid = session["user_id"]
    with connect_db() as conn:
        # threads involving the user's items or sent by user
        rows = conn.execute("""
            SELECT DISTINCT m.thread_id, i.id as item_id, i.title as item_title,
                   MAX(m.created_at) as last_at,
                   COUNT(*) as msg_count
            FROM messages m JOIN items i ON m.item_id=i.id
            WHERE i.user_id=? OR m.sender_id=?
            GROUP BY m.thread_id ORDER BY last_at DESC
        """, (uid, uid)).fetchall()
    return jsonify([dict(r) for r in rows])

# ════════════════════════════════════════════════════════════
# CLAIMS – updated for user accounts
# ════════════════════════════════════════════════════════════

@app.route("/api/claim", methods=["POST"])
def submit_claim():
    d = request.get_json(silent=True) or {}
    item_id = int(d.get("item_id", 0))
    answer  = str(d.get("proof_answer","")).strip()
    if not item_id or not answer:
        return jsonify({"error": "item_id and proof_answer required."}), 400
    with connect_db() as conn:
        item = conn.execute(
            "SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
        if not item: return jsonify({"error": "Not found."}), 404
        if item["item_type"] != "lost":
            return jsonify({"error": "Only lost items can be claimed."}), 400
        if item["status"] == "recovered":
            return jsonify({"error": "Already recovered."}), 409
        if not item["proof_answer_hash"]:
            return jsonify({"error": "No proof challenge on this report."}), 400
        pending = conn.execute(
            "SELECT COUNT(*) FROM claims WHERE item_id=? AND status='pending'",
            (item_id,)).fetchone()[0]
        if pending >= 3:
            return jsonify({"error": "Too many pending claims."}), 429
        correct       = _hash(answer) == item["proof_answer_hash"]
        claimer_token = _token()
        status        = "approved" if correct else "pending"
        uid           = session.get("user_id")
        conn.execute(
            "INSERT INTO claims(item_id,claimer_token,claimer_user_id,proof_answer,proof_correct,status) VALUES(?,?,?,?,?,?)",
            (item_id, claimer_token, uid, "[hidden]", int(correct), status))
        if correct:
            conn.execute("UPDATE items SET status='recovered' WHERE id=?", (item_id,))
            if item["user_id"]:
                _push_user_notif(conn, item["user_id"], "claim_approved",
                    f"Ownership claim approved for report #{item_id}",
                    f"Correct answer submitted for '{item['title']}'.", item_id)
        elif uid:
            _push_user_notif(conn, uid, "claim_pending",
                f"Your claim is pending review",
                f"Claim on '{item['title']}' needs manual review.", item_id)
    if correct:
        return jsonify({"result":"approved","claimer_token":claimer_token,
                        "message":"✅ Ownership verified! Claim approved."})
    return jsonify({"result":"rejected","message":"❌ Answer did not match. Claim recorded for review."})

@app.route("/api/claim/owner", methods=["POST"])
def owner_review_claims():
    d = request.get_json(silent=True) or {}
    token    = str(d.get("owner_token","")).strip()
    claim_id = int(d.get("claim_id", 0))
    action   = str(d.get("action","")).strip().lower()
    if not token or not claim_id or action not in ("approve","reject"):
        return jsonify({"error": "owner_token, claim_id, action required."}), 400
    with connect_db() as conn:
        claim = conn.execute(
            "SELECT c.*,i.owner_token,i.id as iid,i.user_id as owner_uid FROM claims c JOIN items i ON c.item_id=i.id WHERE c.id=?",
            (claim_id,)).fetchone()
        if not claim: return jsonify({"error": "Not found."}), 404
        if claim["owner_token"] != token: return jsonify({"error": "Forbidden."}), 403
        new_status = "approved" if action == "approve" else "rejected"
        conn.execute("UPDATE claims SET status=? WHERE id=?", (new_status, claim_id))
        if action == "approve":
            conn.execute("UPDATE items SET status='recovered' WHERE id=?", (claim["iid"],))
        if claim["claimer_user_id"]:
            _push_user_notif(conn, claim["claimer_user_id"],
                f"claim_{new_status}",
                f"Your claim was {new_status}",
                f"Your ownership claim for report #{claim['iid']} was {new_status}.",
                claim["iid"])
    return jsonify({"message": f"Claim {new_status}."})

@app.route("/api/claims/<int:item_id>")
def get_claims(item_id):
    token = request.args.get("owner_token","").strip()
    if not token: return jsonify({"error": "Token required."}), 403
    with connect_db() as conn:
        item = conn.execute("SELECT owner_token FROM items WHERE id=?", (item_id,)).fetchone()
        if not item or item["owner_token"] != token:
            return jsonify({"error": "Forbidden."}), 403
        rows = conn.execute(
            "SELECT id,status,proof_correct,created_at FROM claims WHERE item_id=? ORDER BY id DESC",
            (item_id,)).fetchall()
    return jsonify([dict(r) for r in rows])

# ════════════════════════════════════════════════════════════
# USER NOTIFICATIONS
# ════════════════════════════════════════════════════════════

@app.route("/api/my/notifications")
@login_required
def my_notifications():
    with connect_db() as conn:
        rows = conn.execute(
            "SELECT * FROM user_notifications WHERE user_id=? ORDER BY id DESC LIMIT 50",
            (session["user_id"],)).fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/api/my/notifications/unread")
@login_required
def my_unread():
    with connect_db() as conn:
        count = conn.execute(
            "SELECT COUNT(*) FROM user_notifications WHERE user_id=? AND seen=0",
            (session["user_id"],)).fetchone()[0]
    return jsonify({"unread": count})

@app.route("/api/my/notifications/mark-read", methods=["POST"])
@login_required
def mark_read():
    d   = request.get_json(silent=True) or {}
    nid = d.get("id")
    with connect_db() as conn:
        if nid:
            conn.execute(
                "UPDATE user_notifications SET seen=1 WHERE id=? AND user_id=?",
                (nid, session["user_id"]))
        else:
            conn.execute(
                "UPDATE user_notifications SET seen=1 WHERE user_id=?",
                (session["user_id"],))
    return jsonify({"message": "Marked read."})

# legacy item-level notifications (kept for backward compat)
@app.route("/api/notifications/<int:item_id>")
def get_notifications(item_id):
    token = request.args.get("owner_token","").strip()
    if not token: return jsonify({"error": "Token required."}), 403
    with connect_db() as conn:
        item = conn.execute("SELECT owner_token FROM items WHERE id=?", (item_id,)).fetchone()
        if not item or item["owner_token"] != token:
            return jsonify({"error": "Forbidden."}), 403
        rows = conn.execute(
            """SELECT n.*,i.title as match_title,i.item_type as match_type,i.location as match_location
               FROM notifications n JOIN items i ON n.match_id=i.id WHERE n.item_id=? ORDER BY n.score DESC""",
            (item_id,)).fetchall()
        conn.execute("UPDATE notifications SET seen=1 WHERE item_id=?", (item_id,))
    return jsonify([dict(r) for r in rows])

@app.route("/api/notifications/unread/<int:item_id>")
def unread_count(item_id):
    with connect_db() as conn:
        count = conn.execute(
            "SELECT COUNT(*) FROM notifications WHERE item_id=? AND seen=0",
            (item_id,)).fetchone()[0]
    return jsonify({"unread": count})

# ════════════════════════════════════════════════════════════
# ADMIN API
# ════════════════════════════════════════════════════════════

def _check_admin():
    if not session.get("user_id") or session.get("role") != "admin":
        return jsonify({"error": "Admin required."}), 403
    return None

@app.route("/api/admin/users")
def admin_users():
    err = _check_admin()
    if err: return err
    with connect_db() as conn:
        rows = conn.execute(
            "SELECT id,username,email,role,created_at FROM users ORDER BY id DESC"
        ).fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/api/admin/users/<int:uid>", methods=["PUT"])
def admin_edit_user(uid):
    err = _check_admin()
    if err: return err
    d = request.get_json(silent=True) or {}
    role = str(d.get("role","")).strip()
    if role not in ("user","admin"):
        return jsonify({"error": "role must be user or admin."}), 400
    with connect_db() as conn:
        conn.execute("UPDATE users SET role=? WHERE id=?", (role, uid))
        _audit(conn, "change_role", "user", uid, f"role -> {role}")
    return jsonify({"message": "User updated."})

@app.route("/api/admin/items/<int:item_id>", methods=["PUT"])
def admin_edit_item(item_id):
    err = _check_admin()
    if err: return err
    d = request.get_json(silent=True) or {}
    with connect_db() as conn:
        item = conn.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
        if not item: return jsonify({"error": "Not found."}), 404
        fields, vals = [], []
        for col in ("status","hidden","title","category","location","description"):
            if col in d:
                fields.append(f"{col}=?"); vals.append(d[col])
        if not fields: return jsonify({"error": "Nothing to update."}), 400
        vals.append(item_id)
        conn.execute(f"UPDATE items SET {','.join(fields)} WHERE id=?", vals)
        _audit(conn, "edit_item", "item", item_id, str(d))
    return jsonify({"message": "Item updated."})

@app.route("/api/admin/claims/<int:claim_id>", methods=["PUT"])
def admin_edit_claim(claim_id):
    err = _check_admin()
    if err: return err
    d = request.get_json(silent=True) or {}
    status = str(d.get("status","")).strip()
    note   = str(d.get("note","")).strip()[:500]
    if status not in ("pending","approved","rejected"):
        return jsonify({"error": "Invalid status."}), 400
    with connect_db() as conn:
        claim = conn.execute(
            "SELECT c.*,i.user_id as owner_uid FROM claims c JOIN items i ON c.item_id=i.id WHERE c.id=?",
            (claim_id,)).fetchone()
        if not claim: return jsonify({"error": "Not found."}), 404
        conn.execute("UPDATE claims SET status=?,admin_note=? WHERE id=?",
                     (status, note, claim_id))
        if status == "approved":
            conn.execute("UPDATE items SET status='recovered' WHERE id=?", (claim["item_id"],))
        # notify claimer if they have an account
        if claim["claimer_user_id"]:
            _push_user_notif(conn, claim["claimer_user_id"], f"claim_{status}",
                f"Admin decision: claim {status}",
                note or f"Your claim was {status} by admin.", claim["item_id"])
        _audit(conn, f"claim_{status}", "claim", claim_id, note)
    return jsonify({"message": f"Claim {status}."})

@app.route("/api/admin/stats")
def admin_stats():
    err = _check_admin()
    if err: return err
    with connect_db() as conn:
        s = dict(conn.execute("""
            SELECT
              (SELECT COUNT(*) FROM items)              AS total_items,
              (SELECT COUNT(*) FROM items WHERE item_type='lost')   AS lost,
              (SELECT COUNT(*) FROM items WHERE item_type='found')  AS found,
              (SELECT COUNT(*) FROM items WHERE status='recovered') AS recovered,
              (SELECT COUNT(*) FROM users)              AS total_users,
              (SELECT COUNT(*) FROM claims)             AS total_claims,
              (SELECT COUNT(*) FROM claims WHERE status='pending')  AS pending_claims,
              (SELECT COUNT(*) FROM items WHERE hidden=1)           AS hidden_items
        """).fetchone())
    return jsonify(s)

if __name__ == "__main__":
    app.run(debug=True)
